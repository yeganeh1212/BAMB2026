function create_local_design(subject_id, par) {
  function seeded_random(seed) {
    var state = seed % 2147483647;
    if (state <= 0) {
      state += 2147483646;
    }
    return function() {
      state = state * 16807 % 2147483647;
      return (state - 1) / 2147483646;
    };
  }

  var rand = seeded_random(subject_id);

  function sample(items) {
    return items[Math.floor(rand() * items.length)];
  }

  function make_block_design(num_trials) {
    var seqdir = [];
    var epinum = [];
    var current_dir = sample([1, 2]);
    var current_episode = 1;
    var trials_until_switch = 4 + Math.floor(rand() * 7);

    for (var i = 0; i < num_trials; i++) {
      if (i > 0 && trials_until_switch <= 0) {
        current_dir = current_dir === 1 ? 2 : 1;
        current_episode += 1;
        trials_until_switch = 4 + Math.floor(rand() * 7);
      }

      seqdir.push(current_dir);
      epinum.push(current_episode);
      trials_until_switch -= 1;
    }

    return {
      seqdir: seqdir,
      epinum: epinum
    };
  }

  function make_sequence_levels(num_trials) {
    var levels = [];
    for (var i = 0; i < num_trials; i++) {
      var sequence = [];
      var sequence_length = 3 + Math.floor(rand() * 4);
      for (var j = 0; j < sequence_length; j++) {
        var magnitude = sample(par.evidence_lvls);
        var sign = rand() < 0.7 ? 1 : -1;
        sequence.push(sign * magnitude);
      }
      levels.push(sequence);
    }
    return levels;
  }

  var order = rand() < 0.5 ? 1 : 2;
  var taskid = order === 1 ? [1, 1, 1, 2, 2, 2] : [2, 2, 2, 1, 1, 1];
  var epimap = [];
  var epinum = [];
  var seqdir = [];
  var seqlvl = [];
  var seqllr = [];

  for (var block = 0; block < par.numBlocks; block++) {
    var num_trials = par.numTrials[par.type[block]];
    var block_design = make_block_design(num_trials);

    epimap.push(sample([1, 2]));
    epinum.push(block_design.epinum);
    seqdir.push(block_design.seqdir);
    seqlvl.push(make_sequence_levels(num_trials));
    seqllr.push([]);
  }

  return {
    taskid: taskid,
    epimap: epimap,
    epinum: epinum,
    seqdir: seqdir,
    seqlvl: seqlvl,
    seqllr: seqllr
  };
}
