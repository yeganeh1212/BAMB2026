function create_trials_design(expeStr, par, seqlvl) {

  var timeline = [];

  // preload images //

  var images = ["img/1.png","img/2.png","img/3.png","img/4.png","img/-4.png","img/-3.png","img/-2.png","img/-1.png",
    "img/BlueOrange.png", "img/OrangeBlue.png", "img/BlueBasket.png", "img/OrangeBasket.png",
    "img/instr/BlueOrangeDemo.png", "img/instr/OrangeBlueDemo.png", "img/instr/BlueOrangeLetters.png", "img/instr/OrangeBlueLetters.png",
    "img/instr/BlueDemo.png", "img/instr/OrangeDemo.png",
    "img/instr/BlueLetters.png", "img/instr/OrangeLetters.png", "img/instr/keyboard.png",
    "img/instr/baskets.png", "img/instr/apples_field.png", "img/instr/confidence.png"
  ];
  var preload = {
    type: 'preload',
    images: images,
    data: {
      trialType: 'preload_images'
    }
  };
  timeline.push(preload);


  //////////// DRAW EVIDENCE ////////////

  // draw lists of evidence levels for all blocks
  // var evidencelvl_list = draw_evidence(par);
  var evidencelvl_list = seqlvl;

  // function to draw apple for one sample in a sequence
  function draw_apple(block, trial, sample, category){
    var evid_lvl = evidencelvl_list[block][trial][sample]; // e.g. -0.5
    var shade = par.evidence_lvls.indexOf(Math.abs(evid_lvl)); // 0/1/2/3 ~ ev. levels
    var colour = (evid_lvl>0 == category); // 0-blue apples, 1-orange apples
    return par.images.apples[+colour][shade];
  };

  ////////////////////////////////////////////////
  //////////// CREATE BLOCKS /////////////////////
  ////////////////////////////////////////////////

  // create instruction chunks for before block 1 and 4
  var instructions_both = create_instructions(par, expeStr);

  var block_time = [2, 4, 4, 2, 4, 4];

  for (var iBl = 0; iBl < par.numBlocks; iBl++) {

    var blockType = par.type[iBl];
    var cond = expeStr.cond[iBl];
    var quest = expeStr.quest[iBl];
    var initdir = expeStr.initdir[iBl];

    if (iBl == 0) { // first practice block
      var instructions = instructions_both[0];
      timeline.push(instructions); // add first block of instructions before practice
    } else if (iBl == 3) { // second practice block
      var instructions = instructions_both[1];
      timeline.push(instructions); // add second block of instructions before practice
    };

    /* define block instructions based on condition */
    var observer_inst = "<p>In this block, press [ "+ par.keys[0][1]+" / "+par.keys[0][0]+" ]"+
      " if you think the computer is picking apples from the " + par.colours[quest]+ " tree.</p>" +
      "<p>Press [ "+ par.keys[1][0]+" / "+par.keys[1][1]+" ]"+
      " if you think the computer is picking apples from the " +par.colours[1-quest] + " tree.</p>" +
      "<img src='"+par.images.responses[cond][quest]+"' style='width:60%;height:auto;' ></img>";
    var actor_inst = " Note that the block starts with your response - you will have to pick at random as you will have no information yet."+
    "<p>Press [ " +par.keys[0][1]+" / "+par.keys[0][0]+" ] or [ " +par.keys[1][0]+" / "+par.keys[1][1]+" ]"+
      " to pick from the " + par.colours[quest] + " tree.</p>" +
      "<img src='"+par.images.responses[cond][quest]+"' style='width:60%;height:auto;' ></img>";

    if (cond == 0) {
      var inst_text = observer_inst;
    } else if (cond == 1) {
      var inst_text = actor_inst;
    };

    if (iBl!=0 && iBl!=3) {
      inst_text += "<p>Keep in mind that the switches happen at about the same rate as in the last block.</p>"
    };


     // create block instructions screen
    var block_inst = {
      type: "html-keyboard-response",
      stimulus: "The following block will take about "+block_time[iBl]+" minutes." +
      inst_text + "<p>Press spacebar to begin.</p>",
      choices: [" "],
      post_trial_gap: 1000,
      data: {
        blockN: iBl,
        blockType: blockType,
        trialType: 'instructions',
        label: 'block_start',
        cond: cond,
        quest: quest,
      },
      on_finish: function(data){
        if((data.blockN+1)==1 | (data.blockN+1)==4){ // after instructions
          hide_cursor();
        }
      }
    };


    //////////////////////////////////////////
    ///// CREATE TEST/PRACTICE TRIALS ////////

    var block = []; // block timeline

    block.push(block_inst);

    if (blockType == "practice") {
      var numTrials = par.numTrials.practice;
    } else if (blockType == "test") {
      var numTrials = par.numTrials.test;
    };

    /// ADD TRIAL RESPONSE -1 AT THE BEGINNING OF EACH ACTOR BLOCK
    if (cond==1){
      var response_0 = {
      type: 'image-keyboard-response',
      stimulus: par.images.responses[cond][quest], // obs/act, question of the block (mapping)
      choices: [par.keys[0][0],par.keys[0][1],par.keys[1][0],par.keys[1][1] ],
      post_trial_gap: function(){
        var cond = jsPsych.data.getLastTrialData().values()[0].cond;
        if (cond == 0){
          return par.iti_obs;
        } else if (cond == 1){
          return par.iti_act;
        }
      },
      data: {
        blockN: iBl,
        blockType: blockType,
        trialType: 'trial',
        cond: cond,
        quest: quest,
        trialN: -1,
        label: 'response',
      },
      on_finish: function(data){
        var press = data.response.toUpperCase();
        data.chosen_side = +par.keys[1].includes(press); // 0 left, 1 right
        if(data.chosen_side == 0){
          data.confidence = par.keys[0].indexOf(press); // 0: low conf, 1: high conf
        } else if (data.chosen_side == 1){
          data.confidence = par.keys[1].indexOf(press);
        };
        data.RT_long = data.rt > par.max_RT; // mark long RTs
      }
    }; // end of response trial
    block.push(response_0);
  }

    // FOR EACH TRIAL CREATE SCREENS
    for(var iTrial = 0; iTrial < numTrials; iTrial++) {

      var seqdir = expeStr.seqdir[iBl][iTrial];
      var correctResp = expeStr.correctResp[iBl][iTrial];

      //////// EVIDENCE SCREENS ////////

      //evidence levels for sequence in this trial
      var evidence_levels = evidencelvl_list[iBl][iTrial]; // e.g. [-0.5, 1, 0.75]
      var seqlen = evidence_levels.length;

      if(cond==0){ // OBSERVER CONDITION

        for (var iSam = 0; iSam < evidence_levels.length; iSam++) {
          var sample = {
            type: 'image-keyboard-response',
            stimulus: draw_apple(iBl, iTrial, iSam, seqdir),
            choices: jsPsych.NO_KEYS,
            //pos: 0,
            trial_duration: par.sampleTime,
            post_trial_gap: function(){
              var last = jsPsych.data.getLastTrialData().values()[0];
              if (last.label == 'evidence' & last.sampleN+2 == last.seqlen){ // if this is the last sample in sequence
                return (par.postSampleGap + par.preResp_obs);
              } else {
                return par.postSampleGap;
              }
            },
            data: {
              blockN: iBl,
              blockType: blockType,
              trialType: 'trial',
              cond: cond,
              quest: quest,
              trialN: iTrial,
              seqdir: seqdir,
              seqcat: seqdir,
              epinum: expeStr.epinum[iBl][iTrial],
              epipos: expeStr.epipos[iBl][iTrial],
              label: 'evidence',
              seqlen: seqlen,
              sampleN: iSam,
              evidlvl: evidence_levels[iSam],
            }
          };
          block.push(sample);
        };

      } else if (cond==1) { // ACTOR CONDITION

        for (var iSam = 0; iSam < evidence_levels.length; iSam++) {
          var sample = {
            type: 'apple-keyboard-response',
            stimulus: function(){
              if (jsPsych.data.getLastTrialData().values()[0].label == 'response'){ // if this is first sample
                var sampleN = 0;
              } else {
                var sampleN =  jsPsych.data.get().last(1).values()[0].sampleN + 1;
              };
              var resp_data = jsPsych.data.get().filter({label: 'response'}).last(1).values()[0];
              var seqdir = expeStr.seqdir[resp_data.blockN][resp_data.trialN+1]; // get seqdir from current block and trial no.
              var seqcat = +(seqdir != resp_data.chosen_side); // draw from 0:blue or 1:orange category
              return draw_apple(resp_data.blockN, resp_data.trialN+1, sampleN, seqcat);
            },
            choices: jsPsych.NO_KEYS,
            pos: function(){
            if (jsPsych.data.get().filter({label: 'response'}).last(1).values()[0].chosen_side==0) {
            return 0;//show apples on the left
            } else if (jsPsych.data.get().filter({label: 'response'}).last(1).values()[0].chosen_side==1) {
            return 1;//show apples on the right
            }
            },//-200,
            trial_duration: par.sampleTime,
            post_trial_gap: function(){
              var last = jsPsych.data.getLastTrialData().values()[0];
              if (last.label == 'evidence' & last.sampleN+2 == last.seqlen){ // if this is the last sample in sequence
                return (par.postSampleGap + par.preResp_act);
              } else {
                return par.postSampleGap;
              }
            },
            data: {
              blockN: iBl,
              blockType: blockType,
              trialType: 'trial',
              cond: cond,
              quest: quest,
              trialN: iTrial,
              seqdir: seqdir,
              epinum: expeStr.epinum[iBl][iTrial],
              epipos: expeStr.epipos[iBl][iTrial],
              label: 'evidence',
              seqlen: seqlen,
              sampleN: iSam,
              evidlvl: function(){
                if (jsPsych.data.getLastTrialData().values()[0].label == 'response'){ // if this is first sample
                  var sampleN = 0;
                } else {
                  var sampleN =  jsPsych.data.get().last(1).values()[0].sampleN + 1;
                };
                var resp_data = jsPsych.data.get().filter({label: 'response'}).last(1).values()[0];
                var evid_lvl = evidencelvl_list[resp_data.blockN][resp_data.trialN+1][sampleN];
                return evid_lvl;
              },
              seqcat: function(){ // copy from stimulus function
                var resp_data = jsPsych.data.get().filter({label: 'response'}).last(1).values()[0]; // data from last response trial
                var seqdir = expeStr.seqdir[resp_data.blockN][resp_data.trialN+1]; // get seqdir from current block and trial no.
                var seqcat = +(seqdir != resp_data.chosen_side); // draw from 0:blue or 1:orange category
                return seqcat;
              },
            }
          };
          block.push(sample);
        }; // end of loop for sample
      }

      //////// RESPONSE SCREEN ////////

      var response = {
        type: 'image-keyboard-response',
        //display 1 or 2 baskets
        stimulus: par.images.responses[cond][quest], // obs/act, question of the block (mapping)
        choices: [par.keys[0][0],par.keys[0][1],par.keys[1][0],par.keys[1][1] ],
        post_trial_gap: function(){
          var cond = jsPsych.data.getLastTrialData().values()[0].cond;
          if (cond == 0){
            return par.iti_obs;
          } else if (cond == 1){
            return par.iti_act;
          }
        },
        data: {
          blockN: iBl,
          blockType: blockType,
          trialType: 'trial',
          cond: cond,
          quest: quest,
          trialN: iTrial,
          seqdir: seqdir,
          epinum: expeStr.epinum[iBl][iTrial],
          epipos: expeStr.epipos[iBl][iTrial],
          label: 'response',
          correctResponse: JSON.stringify(expeStr.correctResp[iBl][iTrial]),//correctResponse: correctResp,
          seqlen: seqlen,
          evidlvl: JSON.stringify(evidencelvl_list[iBl][iTrial]),//evidence_levels,
          seqcat: function(){ // get seqcat from evidence
            var evidence_data = jsPsych.data.getLastTrialData().values()[0];
            return evidence_data.seqcat;
          }
        },
        on_finish: function(data){
          var press = data.response.toUpperCase();
          data.correct = +(data.correctResponse.includes(press)); // 1 correct, 0 incorrect
          data.chosen_side = +par.keys[1].includes(press); // 0 left, 1 right
          if(data.chosen_side == 0){
            data.confidence = par.keys[0].indexOf(press); // 0: low conf, 1: high conf
          } else if (data.chosen_side == 1){
            data.confidence = par.keys[1].indexOf(press);
          };
          data.RT_long = data.rt > par.max_RT; // mark long RTs
        }
      }; // end of response trial

      //in each block,; remove last response screen of ACTOR for avoiding confusion
      if (cond==0){
        block.push(response);
      }
      else if (cond==1 && iTrial<(numTrials-1)) {
        block.push(response);
      }

    }; // end of loop for trial

    // at the end of each block, check reaction times
    var too_slow_screen = {
      type: 'html-keyboard-response',
      stimulus: "<p>We noticed that you took a long time responding a few times. Please make sure that you complete the next block without stopping.</p>"+
      "<p>Press any key to continue.</p>",
      data: {
        blockN: iBl,
        blockType: blockType,
        cond: cond,
        quest: quest,
        trialType: 'instructions',
        label: "too_slow"
      },
    };

    var too_slow = {
      timeline: [too_slow_screen],
      // get data from this block
      conditional_function: function(){
        var blockN = jsPsych.data.getLastTrialData().values()[0].blockN;
        var trials = jsPsych.data.get().filter({blockN:blockN, label:'response'});
        var long_RTs = trials.filter({RT_long:true});
        if (long_RTs.count()/trials.count() > par.max_long_RTs){
          return true;
        }else{
          return false;
        }
      }
    };
    block.push(too_slow);

    var block_chunk = {
      timeline: block
    };

    timeline.push(block_chunk);

    if (blockType=="practice") {

      var repeat_screen = {
        type: 'html-keyboard-response',
        stimulus: "<p>It looks like you have not gotten the hang of it yet. Please read the instructions again so you understand the rules "+
        "of the game. We know that you can do better! <br></br>Press spacebar to continue.</p>",
        choices: [" "],
        data: {
          blockN: iBl,
          blockType: blockType,
          cond: cond,
          quest: quest,
          trialType: 'instructions',
          label: 'repeat_practice',
        },
        on_finish: function(){
          show_cursor();
        }
      };

      var repeat_practice = {
        timeline: [repeat_screen, instructions, block_chunk],
        conditional_function: function(){
          var blockN = jsPsych.data.getLastTrialData().values()[0].blockN;
          var responses = jsPsych.data.get().filter({blockN:blockN, label:'response'});
          var correct_resp = responses.filter({correct:1});
          if (correct_resp.count()/responses.count() < par.minPracPerf){ // if performance on block is lower than min. allowed
            return true;
          }else{
            return false;
          }
        }
      };

      timeline.push(repeat_practice);
    }

    var break_screen = {
      type: 'html-keyboard-response',
      stimulus: function(){
        var blockN = jsPsych.data.getLastTrialData().values()[0].blockN +1;
        if (blockN<6) {
          if(blockN == 5){
            var support_message = "<p>Keep going, you are almost there!</p>";
          }else{
            var support_message = " ";
          };
          return "<p>This is the end of block " + blockN + " out of " +par.numBlocks+".</p>"+ support_message +
          "<p>You can now take a short break. Press space bar to continue to the next block of the game.</p>";
        }else{ // after last block
          return "<p>Well done! This is the end of the apple game.</p>"+
          "<p>Press spacebar to continue to the final questions.</p>";
        }
      },
      choices: [" "],
      data: {
        blockN: iBl,
        blockType: blockType,
        cond: cond,
        quest: quest,
        trialType: 'instructions',
        label: 'break_screen'
      },
      on_finish: function(data){
        if(data.blockN==2){ // before second set of instructions
          show_cursor();
        }
      },
      on_start: function(){
        var block = jsPsych.data.getLastTrialData().values()[0].blockN+1;
        if(block==6){ // after end of task
          should_be_in_fullscreen = false;
          show_cursor();
        }
      }
    };
    timeline.push(break_screen);

  }; // end of loop for block


  var experiment = {
    timeline: timeline
  };

  return experiment;
};
