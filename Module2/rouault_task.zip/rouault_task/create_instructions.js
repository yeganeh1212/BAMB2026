function create_instructions(par, expeStr){

  var key_repeat = "R";
  var key_continue = " ";
  var demo_quest = [expeStr.quest[1], expeStr.quest[4]]; // mapping of the demo trials (different from blocks 1 and 4)
  var colour_reminder = jsPsych.randomization.sampleWithoutReplacement([0,1],1);

  if (expeStr.cond[0]==0) {
    var order = 0; // obs-act
  } else if (expeStr.cond[0]==1) {
    var order = 1; // act-obs
  }

  var images = {
    observer: {
      demo:  ["img/instr/BlueOrangeDemo.png", "img/instr/OrangeBlueDemo.png"],
      letters: ["img/instr/BlueOrangeLetters.png", "img/instr/OrangeBlueLetters.png"],
      confidence: ["img/BlueOrange.png", "img/OrangeBlue.png"]
    },
    actor: {
      demo:  ["img/instr/BlueDemo.png", "img/instr/OrangeDemo.png"],
      letters: ["img/instr/BlueLetters.png", "img/instr/OrangeLetters.png"],
      confidence: ["img/BlueBasket.png", "img/OrangeBasket.png"],
      demoswitch: ["img/instr/DemoSwitch.png"]
    },
    keyboard: "img/instr/keyboard.png"
  };

  ////////// WRITE TEXT //////////

  var text_gen = {actor: {}, observer: {}, both: {}};

  text_gen.both.start = {
    info: "<p>You will <strong>play a game</strong> that will require your full attention and will take about "+
    "40 minutes, with short breaks in between.</p>",
    second: "<p><strong>Please pay very close attention to the following instructions.</strong></p>"+
    "<p>This is a game of alien apples. </p>"+
    "<p>There are two kinds of apple in this game: blue apples and orange apples. </p>"+
    "<p>The apples come from two trees: a <font color=darkblue><strong>blue tree</font></strong> and an <font color=darkorange><strong>orange tree</font></strong>:</p>" +
    "<p><img src='img/instr/baskets.png' style='width:40%;height:auto;' ></img></p>"+
    "<p><ul style='text-align: left'><li> The blue tree has mostly blue apples, but it also has some orange apples.</li><li>"+
    "The orange tree has mostly orange apples, but it also has some blue apples.</li> </ul> </p>",
    third: "<p> This means that:</p>"+
    "<ul style='text-align: left'><li> the more orange an apple is, the more likely it comes from the orange tree.</li>"+
    "<li> the more blue an apple is, the more likely it comes from the blue tree.</li></ul>" +
    "<p><img src='img/instr/apples_field.png' style='width:80%;height:auto;' ></img><br></p>"
  };
  text_gen.both.end = {
    scr_7: "<p>The following short practice is easier to help you see how the game works, but it is still impossible to identify the tree 100% correctly from a single response.</p>"+
    "<p> This means that you can be 'confident' even if you are not absolutely sure.</p>"+
    "<p>Remember that <b>the more "+ par.colours[colour_reminder] +" an apple is, the more likely it comes from the "+ par.colours[colour_reminder] +" tree</b>, and vice versa.</p>",
    scr_8: "<p>Remember that you are indicating both your choice and your confidence.</p>" +
    "<p>Please complete the following practice without stopping.</p>"+
    "<p>Press <b>space bar</b> when you are ready to start, or press <b>[ "+key_repeat+" ]</b> if you want to read the instructions again.</p>",
  };
  text_gen.observer = {
    scr_1: "<p>In the following game, you will observe apples that <strong>the computer</strong> is picking from one of the two trees.</p>" +
    "<p><strong>You will be asked to indicate from which tree (orange or blue) the computer is picking apples.</strong></p>" +
    "<p><strong>This is not easy because you will not see the tree, only the apples that the computer has picked.</strong></p>",
    scr_3: "<p>For example, in this case you will respond <b>[ "+par.keys[0][1]+" ] or [ "+par.keys[0][0]+" ]</b> to indicate "+par.colours[demo_quest[order]]+" and you will respond <b>[ "+par.keys[1][0]+" ] or [ "+par.keys[1][1]+" ]</b> to indicate "+par.colours[1-demo_quest[order]]+": </p>"+
    /// img: baskets with keys
    "<img src='"+images.observer.letters[demo_quest[order]]+"' style='width:40%;height:auto;' ></img>",
    scr_4: "<p>You will also need to indicate whether you are confident or unsure about your response.</p>"+
    "<p>You will press <b>[ "+par.keys[0][1]+" ] or [ "+par.keys[1][1]+" ]</b> if you are fairly confident in your response.</p>"+
    "<p>You will press <b>[ "+par.keys[0][0]+" ] or [ "+par.keys[1][0]+" ]</b> if you are not sure about your response.</p>"+
    "<img src='img/instr/confidence.png' style='width:45%;height:auto;' ></img>" +
    "<p>Click next to try it out.</p>",
    scr_6: "<p>Well done!</p>"+
    "<p>To help you with this game, please consider the following:</p><p><strong><font color=purple>The computer picks from the same tree <b>for some time, and occasionally switches</b> " +
    "to the other tree.</strong></font></p>"+
    "<p>This means that <strong><font color=darkpink>you should remember your previous responses </font> to figure out from which tree the computer is currently picking apples.</strong>" +
    "<p><strong><font color=purple>Responding based only on the last apples seen can be misleading, since the two trees have apples of the two colors.</strong></font></p>"
  };
  text_gen.actor = {
    scr_1: "<p>In the following game, <strong>you</strong> will be picking apples from one of the two trees.</p>"+
    "<p><strong>You will be asked to either 'Pick apples from the blue tree' or to 'Pick apples from the orange tree' -"+
    "<p>you will have to figure out which side (left or right) is currently associated with the requested tree.</strong>"+
    "<br></br>This is not easy because you will only see the apples that you have picked.</p>",
    scr_3: "<p><br>Either the orange tree is on the left side and the blue tree on the right side, or the other way around.</br><strong><font color=green>In other words, either the keys <b>[ "+par.keys[0][1]+" ]</b> and <b>[ "+par.keys[0][0]+" ]</b> pick apples from the blue tree and the keys <b>[ "+par.keys[1][0]+" ]</b> "+
    "and <b>[ "+par.keys[1][1]+" ]</b> pick apples from the orange tree, or the other way around. <br></br>Your job is to press keys to pick apples from the requested tree.</strong></font></p>",
    scr_4: "<p>You will also need to indicate whether you are confident or unsure about your response.</p>"+
    "<p>You will press <b>[ "+par.keys[0][1]+" ]</b> or <b>[ "+par.keys[1][1]+" ]</b> if you are fairly confident in your response and "+
    "you will press <b>[ "+par.keys[0][0]+" ]</b> or <b>[ "+par.keys[1][0]+" ]</b> if you are not sure.<br></br>Your confidence WILL NOT affect which apples you will pick.</p>"+
      //// img: basket + confidence
    "<img src='"+images.actor.confidence[demo_quest[order]]+"' style='width:55%;height:auto;' ></img>" +
    "<p>Click next to see an example.</p>",
    scr_6: "<p>Well done!</p>"+
    "<p>To help you with this game, please consider the following:<br></br></p><p><strong><font color=goldenrod>The side that is associated with the requested tree <b>stays the same for some time, and occasionally switches to the other side.</b>" +
    "<p>In other words, the trees switch from time to time between these two situations:</p>" +
    "<img src='"+images.actor.demoswitch[0]+"' style='width:55%;height:auto;' ></img>" +
    "<p>This means that <strong><font color=darkpink>you should remember your previous responses </font>to figure out which side is currently associated with the requested tree.</strong>" +
    "<p><strong><font color=goldenrod>Responding based only on the last apples seen can be misleading, since the two trees have apples of the two colors.</strong></font></p>"
  };


  var text_spec = {observer: {}, actor: {}};

  text_spec.observer.obsact = {
    scr_1: "<p>On the next screen, you will try indicating your decision by pressing [ "+par.keys[0][1] +" ] or [ "+par.keys[1][1]+" ].</p>",
    scr_3: "<p>In the real game, you will be responding with four keys, not two, which will be explained next.<br></br> <strong>Each tree will be associated with one hand:</strong></p>" +
    // img: keyboard
    "<img src='"+images.keyboard+"' style='width:45%;height:auto;' ></img>"
  };

  text_spec.observer.actobs = {
    scr_0: "<p>You will now play a different game with the same apples. This time, <b>the computer will be picking apples, not you.</b></p>",
  };

  text_spec.actor.actobs = {
    scr_1: "<p>With one hand, you will pick apples from the orange tree, and with the other one, from the blue tree. <br></br> At first, <b>you won&#39;t know which hand is associated with which tree.</b> "+
    "However, by watching the apples picked following your key presses, you can figure it out.</strong></p>"+
    "<p>Click next to see an example.</p>",
    scr_3: "<p>Remember that all the apples you just saw were picked from the tree on the side that you pressed. <br></br>In the real game, you will be responding with four keys, not two, which will be explained next:</p>" +
      "<img src='img/instr/keyboard.png' style='width:45%;height:auto;' ></img>" +
      "<p><b>[ "+par.keys[0][1]+" ]</b> and <b>[ "+par.keys[0][0]+" ]</b> will be associated with one tree and <b>[ "+par.keys[1][0]+" ]</b> and <b>[ "+par.keys[1][1]+" ]</b> with the other tree.</p>",
  };

  text_spec.actor.obsact = {//WARNING THIS VAR OR THE PREVIOUS IS STRANGE
    scr_0: "<p>You will now play a different game with the same apples. This time, you will be picking apples, not the computer.</p>",
    scr_1: "<p>With one hand, you will pick apples from the orange tree, and with the other one, from the blue tree.  At first, <b>you won&#39;t know which hand "+
    "is associated with which tree.</b> However, by watching the apples picked following your key presses, you can figure it out.</p>",
    scr_3: "<p></p>" +
    "<img src='"+images.actor.letters[demo_quest[order]]+"' style='width:40%;height:auto;' ></img>"
  };

  //////////////////////////////////////////////
  ////////// CREATE INSTRUCTION PAGES //////////
  //////////////////////////////////////////////

  var start_screen = {
    type: 'instructions-min-viewing-time',
    pages: [text_gen.both.start.info],
    show_clickable_nav: true,
    min_viewing_time: 1000,//par.min_view_time,
    data: {
      trialType: 'instructions',
      label: 'instr_0',
    },
  };


  var instr_last = {
    type: 'html-keyboard-response',
    stimulus: text_gen.both.end.scr_8,
    choices: [key_repeat, key_continue],
    data: {
      trialType: 'instructions',
      cond: function(){
        jsPsych.data.get().filter({label: 'quiz'}).last(1).values()[0].cond;
      },
      label: 'instr_last'
    },
  };


  //// obsact_1: block 1 observer, obsact_2: block 4 actor ////
  // BLOCK 1
  var obsact_1a = {
    type: 'instructions-min-viewing-time',
    pages: [
      text_gen.both.start.second,
      text_gen.both.start.third,
      text_gen.observer.scr_1 + text_spec.observer.obsact.scr_1,
      ],
    show_clickable_nav: true,
    min_viewing_time: par.min_view_time,
    data: {
      trialType: 'instructions',
      cond: 0,
      label: 'instr_2'
    },
  };

  var obsact_1b = {
    type: 'instructions-min-viewing-time',
    pages: [
      text_spec.observer.obsact.scr_3 + text_gen.observer.scr_3,
      text_gen.observer.scr_4,
      ],
    show_clickable_nav: true,
    min_viewing_time: par.min_view_time,
    data: {
      trialType: 'instructions',
      cond: 0,
      label: 'instr_3'
    },
  };
  var obsact_1c = {
    type: 'instructions-min-viewing-time',
    pages: [
      text_gen.observer.scr_6,
      text_gen.both.end.scr_7,
    ],
    min_viewing_time: par.min_view_time,
    show_clickable_nav: true,
    data: {
      trialType: 'instructions',
      cond: 0,
      label: 'instr_4'
    },
  };


  // BLOCK 4 - actor
  var obsact_2a = {
    type: 'instructions-min-viewing-time',
    pages: [
      text_spec.actor.obsact.scr_0,
      text_gen.actor.scr_1 + text_spec.actor.obsact.scr_1,
      text_gen.actor.scr_3 + text_spec.actor.obsact.scr_3,
      text_gen.actor.scr_4,
    ],
    min_viewing_time: par.min_view_time,
    show_clickable_nav: true,
    data: {
      trialType: 'instructions',
      cond: 1,
      label: 'instr_1'
    },
  };

  var obsact_2b = {
    type: 'instructions-min-viewing-time',
    pages: [
      text_gen.actor.scr_6,
      text_gen.both.end.scr_7,
    ],
    show_clickable_nav: true,
    min_viewing_time: par.min_view_time,
    data: {
      trialType: 'instructions',
      cond: 1,
      label: 'instr_2'
    },
  };

  //// actobs_1: Actor block 1, actobs_2: observer block 4 ////
 //// BLOCK 1 = ACTOR
  var actobs_1a = {
    type: 'instructions-min-viewing-time',
    pages: [
      text_gen.both.start.second,
      text_gen.both.start.third,
      text_gen.actor.scr_1 + text_spec.actor.actobs.scr_1
      ],
    min_viewing_time: par.min_view_time,
    show_clickable_nav: true,
    data: {
      trialType: 'instructions',
      cond: 1,
      label: 'instr_1'
    },
  };
  var actobs_1b = {
    type: 'instructions-min-viewing-time',
    pages: [
      text_spec.actor.actobs.scr_3 + text_gen.actor.scr_3,
      text_gen.actor.scr_4
    ],
    min_viewing_time: par.min_view_time,
    show_clickable_nav: true,
    data: {
      trialType: 'instructions',
      cond: 1,
      label: 'instr_2'
    },
  };
  var actobs_1c = {
    type: 'instructions-min-viewing-time',
    pages: [
      text_gen.actor.scr_6,
      text_gen.both.end.scr_7,
    ],
    min_viewing_time: par.min_view_time,
    show_clickable_nav: true,
    data: {
      trialType: 'instructions',
      cond: 1,
      label: 'instr_3'
    },
  };
  //// BLOCK 4 (observer)
  var actobs_2a = {
    type: 'instructions-min-viewing-time',
    pages: [
      text_spec.observer.actobs.scr_0,
      text_gen.observer.scr_1,
      text_gen.observer.scr_3,
      text_gen.observer.scr_4
    ],
	min_viewing_time: par.min_view_time,
    show_clickable_nav: true,
    data: {
      trialType: 'instructions',
      cond: 0,
      label: 'instr_1'
    },
  };
  var actobs_2b = {
    type: 'instructions-min-viewing-time',
    pages: [
      text_gen.observer.scr_6,
      text_gen.both.end.scr_7,
    ],
	min_viewing_time: par.min_view_time,
    show_clickable_nav: true,
      data: {
      trialType: 'instructions',
      cond: 0,
      label: 'instr_2'
    },
  };

   //////   QUIZ TO CHECK UNDERSTANDING /////
   /////////////////////////////////////////

   var quiz = {
     observer: {
       type: 'survey-multi-choice',
       preamble: '<b>Please answer some questions about your understanding of the game:</b>',
       questions: [
         {prompt: "Each tree contains apples apples from both colors.",
         options: ["True", "False"], name: 'colours', required: true},
         {prompt: "The computer picks apples...",
         options: ["always from the same tree", "at random from one of the trees", "from one tree for some time and then switches"], name: 'reversals', required: true},
       ],
       data: {
         trialType: 'instructions',
         cond: 0,
         label: "quiz"
       },
       on_finish: function(data){
         if(data.response['colours']=='True' & data.response['reversals']=='from one tree for some time and then switches'){
           data.correct = 1;
         } else {
           data.correct = 0;
         }
       },
     },
     actor: {
       type: 'survey-multi-choice',
       preamble: '<b>Please answer some questions about your understanding of the game:</b>',
       questions: [
         {prompt: "The blue tree contains not only blue apples, but also some orange apples.",
         options: ["True", "False"], name: 'colours', required: true},
         {prompt: "The requested tree is associated with...",
         options: ["always one side", "either side at random", "one side for some time and then the other side"], name: 'reversals', required: true},
         {prompt: "When the left keys pick apples from the blue tree, the right keys pick apples from...",
         options: ["the blue tree too", "the orange tree", "impossible to say"], name: 'baskets', required: true},
       ],
       data: {
         trialType: 'instructions',
         cond: 1,
         label: "quiz"
       },
       on_finish: function(data){
         if(data.response['colours']=='True' & data.response['reversals']=='one side for some time and then the other side' & data.response['baskets']=="the orange tree"){
           data.correct = 1;
         } else {
           data.correct = 0;
         }
       },
     }
   };

   var repeat_screen = {
     type: 'html-button-response',
     stimulus: '<p>Please read the instructions again carefully.</p>',
     choices: ["Continue"],
     data: {
       trialType: 'instructions',
       label: 'repeat_inst',
       data: function(){
         jsPsych.data.getLastTrialData().values()[0].cond;
       }
     }
   };

   var repeat_instr = {
     timeline: [repeat_screen],
     conditional_function: function(){
       var quiz_resp = jsPsych.data.get().filter({label: 'quiz'}).last(1).values()[0];
       if(quiz_resp.correct == 0){ // If they made a mistake on the quiz
         return true;
       }else{
         return false;
       }
     }
   };

   ////////////////////////////////////////////////
   ////////// CREATE DEMO RESPONSE TRIALS //////////

   // returns three chunks, two for block 1 and one for block 4 - dependent on order
   var demo = create_demo(par, order, demo_quest, images);

   ////////////////////////////////////////////////
   ////// MERGE TRIALS INTO CHUNKS ///////////////

   var ObsAct_1 = { // block 1 instructions (observer)
     timeline: [obsact_1a, demo[0], obsact_1b, demo[1], obsact_1c, quiz.observer, repeat_instr],
     loop_function: function(data){
       var quiz_resp = jsPsych.data.get().filter({label: 'quiz'}).last(1).values()[0];
       if(quiz_resp.correct == 0){ // If they made a mistake on the quiz
         return true;
       }else{
         return false;
       }
     },
   };

   var ObsAct_obs = { // block 1 instructions (observer)
     timeline: [start_screen, ObsAct_1, instr_last],//[start_screen, ObsAct_1, instr_last, end_screen],
     loop_function: function(data){
       if(data.last(1).values()[0].response == key_repeat.toLowerCase()){ // If they want to repeat instructions
         return true;
       }else{
         return false;
       }
     },
   };

   var ObsAct_2 = { // block 4 instructions (actor)
     timeline: [obsact_2a, demo[2], obsact_2b, quiz.actor, repeat_instr],
     loop_function: function(data){
       var quiz_resp = jsPsych.data.get().filter({label: 'quiz'}).last(1).values()[0];
       if(quiz_resp.correct == 0){ // If they made a mistake on the quiz
         return true;
       }else{
         return false;
       }
     },
   };

   var ObsAct_act = { // block 4 instructions (actor)
     timeline: [ObsAct_2, instr_last],//[ObsAct_2, instr_last, end_screen],
     loop_function: function(data){
       if(data.last(1).values()[0].response == key_repeat.toLowerCase()){ // If they want to repeat instructions
         return true;
       }else{
         return false;
       }
     },
   };


   var ActObs_1 = { // block 1 instructions (actor)
     timeline: [actobs_1a, demo[0], actobs_1b, demo[1], actobs_1c, quiz.actor, repeat_instr], // inst, demo, inst, demo, inst
     loop_function: function(data){
       var quiz_resp = jsPsych.data.get().filter({label: 'quiz'}).last(1).values()[0];
       if(quiz_resp.correct == 0){ // If they made a mistake on the quiz
         return true;
       }else{
         return false;
       }
     },
   };

   var ActObs_act = {
     timeline: [start_screen, ActObs_1, instr_last],//[start_screen, ActObs_1, instr_last, end_screen],
     loop_function: function(data){
       if(data.last(1).values()[0].response == key_repeat.toLowerCase()){ // If they want to repeat instructions
         return true;
       }else{
         return false;
       }
     },
   };

   var ActObs_2 = { // block 4 instructions (observer)
     timeline: [actobs_2a, demo[2], actobs_2b, quiz.observer, repeat_instr],
     loop_function: function(data){
       var quiz_resp = jsPsych.data.get().filter({label: 'quiz'}).last(1).values()[0];
       if(quiz_resp.correct == 0){ // If they made a mistake on the quiz
         return true;
       }else{
         return false;
       }
     },
   };

   var ActObs_obs = {
     timeline: [ActObs_2, instr_last],//[ActObs_2, instr_last, end_screen],
     loop_function: function(data){
       if(data.last(1).values()[0].response == key_repeat.toLowerCase()){ // If they want to repeat instructions
         return true;
       }else{
         return false;
       }
     },
   };


  // output = an array of two sets of instructions, depending on expeStr.cond[0]
  if (order==0) {
    return [ObsAct_obs, ObsAct_act];
  } else if (order==1) {
    return [ActObs_act, ActObs_obs];
  }
};
