
/////// FUNCTION TO DEFINE EXPERIMENT STRUCTURE ////////////

function create_exp_design(subjID, par, taskid, epimap, seqdirdesign, epinum){

var expeStr = {}; // object for exp structure

// epimap is about colour-key mappings:  for observer ~ basket positions (0:BlueOrange, 1:OrangeBlue)
// for actor ~ basket to draw from (0:Blue, 1:Orange)
// re-organise epimap 0/1 instead of 1/2
var c = epimap,
  d = [1,1,1,1,1,1],
  x = [];
for(var i = 0;i<=d.length-1;i++)
  x.push(c[i] - d[i]);
  expeStr.quest = x;

// re-organise taskid 0/1 instead of 1/2
var a = taskid,
  b = [1,1,1,1,1,1],
  x = [];
for(var i = 0;i<=b.length-1;i++)
  x.push(a[i] - b[i]);
  expeStr.cond = x;
//  expeStr.cond = jsPsych.randomization.sampleWithoutReplacement([ [1,1,1,0,0,0],[0,0,0,1,1,1] ], 1)[0];



// reorganise initdir on the basis seqdirdesign, first element of each block
// this determines the initial direction for each block ('epidir')
// 0:Blue/blue-left, 1:Orange/orange-left
expeStr.initdir = [];
for (var iBl = 0; iBl < par.numBlocks; iBl++) {
  expeStr.initdir.push(seqdirdesign[iBl][0]-1);
}
//expeStr.initdir = jsPsych.randomization.repeat([0,1], par.numBlocks/2);






  //create list of episode numbers (epinum) and position of trial within the episode (epipos)
  expeStr.epinum = epinum;

  var trial_in_epi = [];//this is epipos
    for (var iBl=0; iBl < par.numBlocks; iBl++) { // for each block
      trial_in_epi[iBl] = [];
   
      for (var iTrial=0; iTrial < epinum[iBl].length; iTrial++) { // for each trial
        if(epinum[iBl][iTrial] != epinum[iBl][iTrial-1]){
          var count = 1;
        };
        trial_in_epi[iBl][iTrial] = count;
        count++;
      }
    };
  expeStr.epipos = trial_in_epi;




  //////////// CREATE BLOCK TRIAL VARIABLES ////////////
  
  //expeStr.seqlen = [];//ai vire seqlen car restait vide anyway
  expeStr.correctResp = [];
  expeStr.seqdir = [];

  for (var iBl = 0; iBl < par.numBlocks; iBl++) {

    var correct_responses = [];
    var seq_lengths = [];
    var seqdirs = []; // states

    if (par.type[iBl] == "practice") {
      var numTrials = par.numTrials.practice;
    } else if (par.type[iBl] == "test") {
      var numTrials = par.numTrials.test;
    };

        for(var iTrial = 0; iTrial < numTrials; iTrial++) {

          // determine state (seqdir)
          // actor: 0 = left-blue, right-orange, 1 = oppos.; observer: 0 = drawing from blue, 1 = from orange
          var same_or_diff = expeStr.epinum[iBl][iTrial] % 2 == 0; // --> 0 for odd and 1 for even numbers
          var seqdir = seqdirdesign[iBl][iTrial]-1;//Math.abs(+same_or_diff - expeStr.initdir[iBl]);
          seqdirs.push(seqdir);//convert seqdir en 0/1 au lieu de 1/2

          // Calculate correct response for trial and save outside the loop
          var quest_vs_state = expeStr.quest[iBl] != seqdir; // 0 if same, 1 if different
          var correct_response = par.keys[+quest_vs_state]; // ('+' converts to integer) // list
          correct_responses.push(correct_response);
        };

    //expeStr.seqlen.push(seq_lengths);
    expeStr.correctResp.push(correct_responses);
    expeStr.seqdir.push(seqdirs);
  }; // end of loop for block


  return expeStr;
};
