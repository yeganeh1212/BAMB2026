function create_demo(par, order, demo_quest, images){

  var evid_list_easy = [1, 0.75, -0.5, 1, 0.25];
  var evid_list_hard = [0.75, -0.25, 1, -0.5, 0.25, 0.5];

  function draw_apple(evid_list, sample, category){
    var evid = evid_list[sample]; // e.g. -0.5
    var shade = par.evidence_lvls.indexOf(Math.abs(evid)); // 0/1/2/3 ~ ev. levels
    var colour = ((evid>0) == category); // 0-blue apples, 1-orange apples
    return par.images.apples[+colour][shade];
  };


  ////////// OBSERVER //////////
  //////////////////////////////

  ////////// Screen 2 ///////// (first demo)
  var obs_scr_2 = [];
  for (var iS=0; iS<evid_list_easy.length; iS++){
    var sample = {
      type: 'image-keyboard-response',//'apple-keyboard-response',
      stimulus: draw_apple(evid_list_easy, iS, 1-demo_quest[0]), // draw from right basket for all Ps
      choices: jsPsych.NO_KEYS,
      //pos: 0,
      trial_duration: par.sampleTime,
      post_trial_gap: function(){
        var sampleN = jsPsych.data.getLastTrialData().values()[0].sampleN+1;
        if (sampleN+1!=evid_list_easy.length) { // if this is NOT the last sample in sequence
          return par.postSampleGap;
        } else { // if this is the last sample in sequence
          return (par.postSampleGap + par.preResp_obs);
        }
      },
      data: {
        trialType: 'demo',
        label: 'evidence',
        cond: 0,
        quest: demo_quest[0],
        sampleN: iS,
        seqlen: evid_list_easy.length,
        seqdir: 1-demo_quest[0],
      },
    };
    obs_scr_2.push(sample);
  };

  var resp = {
    type: 'image-keyboard-response',
    stimulus: images.observer.demo[demo_quest[0]],
    choices: [par.keys[0][1], par.keys[1][1]],
    post_trial_gap: par.iti_obs,
    data: {
      trialType: 'demo',
      label: 'response',
      cond: 0,
      quest: demo_quest[0],
      seqdir: 1-demo_quest[0],
    },
  };
  obs_scr_2.push(resp);

  ////////// Screen 5 ///////// (second demo)

  var obs_scr_5 = [];

  for (var iS=0; iS<evid_list_hard.length; iS++){
    var sample = {
      type: 'image-keyboard-response',//'apple-keyboard-response',
      stimulus: draw_apple(evid_list_hard, iS, 1-demo_quest[order]),
      choices: jsPsych.NO_KEYS,
      //pos: 0,
      trial_duration: par.sampleTime,
      post_trial_gap: function(){
        var sampleN = jsPsych.data.getLastTrialData().values()[0].sampleN+1;
        if (sampleN+1!=evid_list_hard.length) { // if this is NOT the last sample in sequence
          return par.postSampleGap;
        } else { // if this is the last sample in sequence
          return (par.postSampleGap + par.preResp_obs);
        }
      },
      data: {
        trialType: 'demo',
        label: 'evidence',
        cond: 0,
        quest: demo_quest[order],
        sampleN: iS,
        seqlen: evid_list_hard.length,
        seqdir: 1-demo_quest[order],
      },
    };
  obs_scr_5.push(sample);
  };

  var resp = {
    type: 'html-keyboard-response',
    stimulus: "Which key would you press to indicate that you think the apples came from the "+par.colours[1-demo_quest[order]]+" tree, but you are not very confident?</p>"+
    "<img src='"+images.observer.confidence[demo_quest[order]]+"' style='width:70%;height:auto;' ></img>",
    choices: [par.keys[0][0],par.keys[0][1],par.keys[1][0],par.keys[1][1]],
    post_trial_gap: par.iti_obs,
    data: {
      trialType: 'demo',
      label: 'response',
      cond: 0,
      quest: demo_quest[order],
      sampleN: iS,
      seqdir: 1-demo_quest[order],
      correctResponse: par.keys[1][0], // 'O'
    },
    on_finish: function(data){
      data.correct = +(data.response.toUpperCase() == data.correctResponse);
    }
  };
  obs_scr_5.push(resp);


  ////////// ACTOR /////////////
  //////////////////////////////
  ////////// Screen 2 ///////// (first demo - actor)

  var act_scr_2 = [];
  var resp = {
    type: 'image-keyboard-response',
    stimulus: images.actor.demo[demo_quest[0]],
    choices: [par.keys[0][1], par.keys[1][1]],
    post_trial_gap: par.iti_act,
    data: {
      trialType: 'demo',
      cond: 1,
      label: 'response',
      quest: demo_quest[0],
      seqdir: 1-demo_quest[0],
    },
    on_finish: function(data){
      data.chosen_side = +par.keys[1].includes(data.response.toUpperCase()); // 0 left, 1 right
    }
  };
  act_scr_2.push(resp);

  for (var iS=0; iS<evid_list_easy.length; iS++){
    var sample = {
      type: 'apple-keyboard-response',
      // always draw from the basket that is requested
      stimulus: draw_apple(evid_list_easy, iS, demo_quest[0]),
      choices: jsPsych.NO_KEYS,
      pos: function(){
        if (jsPsych.data.get().filter({label: 'response'}).last(1).values()[0].chosen_side==0) {
        return 0;//show apples on the left
        } else if (jsPsych.data.get().filter({label: 'response'}).last(1).values()[0].chosen_side==1) {
        return 1;//show apples on the right
        }
      },
      trial_duration: par.sampleTime,
      post_trial_gap: function(){
        var sampleN = jsPsych.data.getLastTrialData().values()[0].sampleN +1;
        if (sampleN+1!=evid_list_easy.length) { // if this is NOT the last sample in sequence
          return par.postSampleGap;
        } else { // if this is the last sample in sequence
          return (par.postSampleGap + par.preResp_act);
        }
      },
      data: {
        trialType: 'demo',
        label: 'evidence',
        cond: 1,
        sampleN: iS,
        seqlen: evid_list_easy.length,
        quest: demo_quest[0],
        seqdir: 1-demo_quest[0],
      }
    };
  act_scr_2.push(sample);
  };

  ////////// Screen 5 ///////// (second demo - actor)
  var act_scr_5 = [];
  var resp_1 = {
    type: 'html-keyboard-response',
    stimulus: "<p>On the first trial, it is impossible to know. Just pick a side by pressing [ "+par.keys[0][0]+" ] or [ "+par.keys[1][0]+" ] (which indicates that you are unsure) and see what happens.</p>"+
    "<img src='"+images.actor.confidence[demo_quest[order]]+"' style='width:70%;height:auto;' ></img>",
    choices: [par.keys[0][0],par.keys[0][1],par.keys[1][0],par.keys[1][1]],
    post_trial_gap: par.iti_act,
    data: {
      trialType: 'demo',
      label: 'response',
      cond: 1,
      quest: demo_quest[order],
      seqdir: 1-demo_quest[order],
    },
    on_finish: function(data){
      data.chosen_side = +par.keys[1].includes(data.response.toUpperCase());
    }
  };
  act_scr_5.push(resp_1);

  for (var iS=0; iS<evid_list_hard.length; iS++){
    var sample = {
      type: 'apple-keyboard-response',
      stimulus: draw_apple(evid_list_hard, iS, demo_quest[order]),
      choices: jsPsych.NO_KEYS,
      pos: function(){
        if (jsPsych.data.get().filter({label: 'response'}).last(1).values()[0].chosen_side==0) {
        return 0;//show apples on the left
        } else if (jsPsych.data.get().filter({label: 'response'}).last(1).values()[0].chosen_side==1) {
        return 1;//show apples on the right
        }
      },//-200,
      trial_duration: par.sampleTime,
      post_trial_gap: function(data){
        var sampleN = jsPsych.data.getLastTrialData().values()[0].sampleN+1;
        if (sampleN+1!=evid_list_hard.length) { // if this is NOT the last sample in sequence
          return par.postSampleGap;
        } else { // if this is the last sample in sequence
          return (par.postSampleGap + par.preResp_act);
        }
      },
      data: {
        trialType: 'demo',
        label: 'evidence',
        cond: 1,
        sampleN: iS,
        seqlen: evid_list_hard.length,
        quest: demo_quest[order],
        seqdir: 1-demo_quest[order],
      }
    };
    act_scr_5.push(sample);
  };

  var resp_2 = {
    type: 'html-keyboard-response',
    stimulus: function(){
      if(jsPsych.data.get().filter({label: 'response'}).last(1).values()[0].chosen_side==1){
        var request = "RIGHT";
      } else if(jsPsych.data.get().filter({label: 'response'}).last(1).values()[0].chosen_side==0){
        var request = "LEFT";
      }
      return "<p>Which key would you press to indicate that the keys on the "+request+" are picking apples that correspond to the requested tree and you are confident in your response?</p>"+
      "<img src='"+images.actor.confidence[demo_quest[order]]+"' style='width:70%;height:auto;' ></img>";
    },
    choices: [par.keys[0][0],par.keys[0][1],par.keys[1][0],par.keys[1][1]],
    post_trial_gap: par.iti_act,
    data: {
      trialType: 'demo',
      label: 'evidence',
      cond: 1,
      seqcat: 1-demo_quest[order],
      sampleN: iS,
      quest: demo_quest[order],
      seqdir: 1-demo_quest[order],
    },
    on_finish: function(data){
      var first_resp = jsPsych.data.get().filter({label: 'response'}).last(1).values()[0].chosen_side; // 0 or 1
      data.correct = data.response.toUpperCase() == par.keys[first_resp][1] ;
    }
  };
  act_scr_5.push(resp_2);

  ///////// CONDITIONAL SCREENS //////////

  var wrong_scr = {
    type: 'html-keyboard-response',
    stimulus: "You did not press the correct key. Try again!",
    trial_duration: 2000,
    data: {
      trialType: 'instructions',
      label: 'instr_incorrect'
    }
  };
  var cond_wrong_scr = {
    timeline: [wrong_scr],
    conditional_function: function(){
      if(jsPsych.data.get().last(1).values()[0].correct){
        return false;
      } else {
        return true;
      }
    }
  };
  obs_scr_5.push(cond_wrong_scr);
  act_scr_5.push(cond_wrong_scr);

  //// CREATE CHUNKS /////
  ////////////////////////

  var chunk_obs_scr_2 = {
    timeline: obs_scr_2,
  };
  var chunk_obs_scr_5 = {
    timeline: obs_scr_5,
    loop_function: function(data){
      if(data.last(1).values()[0].label=='instr_incorrect'){ // if error message was shown
        return true;
      }else{
        return false;
      }
    },
  };

  var chunk_act_scr_2 = {
    timeline: act_scr_2,
  };
  var chunk_act_scr_5 = {
    timeline: act_scr_5,
    loop_function: function(data){
      if(data.last(1).values()[0].label=='instr_incorrect'){
        return true;
      }else{
        return false;
      }
    },
  };

  // return three chunks, two for block 1 and one for block 4 - dependent on order
  if(order==0){ // obs-act
    var demo = [chunk_obs_scr_2, chunk_obs_scr_5, chunk_act_scr_5];
  } else if(order==1){ // act-obs
    var demo = [chunk_act_scr_2, chunk_act_scr_5, chunk_obs_scr_5];
  }

  return demo;
}
